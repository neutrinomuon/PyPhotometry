# Filters available in PyPhotometry - ASCII format

# There are some filters with negative values from the original sources, for example, Herschel filters.